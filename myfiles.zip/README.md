# GovDz.Im

This is my personal website where you can find how to contact me in diffrent plateforms using PGP Encryption KEY .

## Skills

Here are some of my skills:

- CVEs explorer
- BugBounty
- Ethical Hacking 
- Pentesting

## Contact Me

You can reach me by diffrent ways i made on my website : https://govdz.im ; Check it out !


## Installation

1. Clone this repository to your local machine
2. Open `index.html` in your web browser

## Credits

This website was created using HTML and CSS.
