<?php
    
    if( $this->options->get('pop-ad-status') ) {
        echo $this->options->get('pop-ad-code');
    }
