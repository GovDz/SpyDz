(function($, admin_base_url) {"use strict";
CKEDITOR.replace('body');
})(jQuery, admin_base_url)